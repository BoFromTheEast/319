/* 
Name : Bo Oo
Feb 11, 2024
Activity06 - Arrays
*/

console.log("---- I am in A R R A Y S ----")

// Q1 : Index of each color
let colors = ['red', 'blue', 'orange']
console.log(colors[0]);


// Q2 : Add a new element 'green'
colors[3] = 'green';
console.log(colors);

// Q3 : Length of the Array
console.log(colors.length);

